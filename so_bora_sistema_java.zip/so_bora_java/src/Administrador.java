public class Administrador extends Pessoa {
    private String nivelAcesso;

    public Administrador(String nome, int idade, double altura, String nivelAcesso) {
        super(nome, idade, altura);
        this.nivelAcesso = nivelAcesso;
    }

    @Override
    public void SeApresentar() {
        System.out.println("Tipo: Administrador");
        super.SeApresentar();
        System.out.println("Nivel de acesso: " + nivelAcesso);
    }

    public void gerenciarEspacos(SistemaAgendamento sistema, EspacoEsportivo espaco) {
        sistema.cadastrarEspaco(espaco);
    }

    public void gerenciarAgendamentos(SistemaAgendamento sistema) {
        sistema.listarAgendamentos();
    }
}
