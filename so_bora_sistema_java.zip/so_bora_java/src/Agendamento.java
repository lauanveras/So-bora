import java.time.LocalDate;
import java.time.LocalTime;

public class Agendamento {
    private int id;
    private Usuario usuario;
    private EspacoEsportivo espaco;
    private LocalDate data;
    private LocalTime horario;
    private String status;

    public Agendamento(int id, Usuario usuario, EspacoEsportivo espaco,
                       LocalDate data, LocalTime horario, String status) {
        this.id = id;
        this.usuario = usuario;
        this.espaco = espaco;
        this.data = data;
        this.horario = horario;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public EspacoEsportivo getEspaco() {
        return espaco;
    }

    public LocalDate getData() {
        return data;
    }

    public LocalTime getHorario() {
        return horario;
    }

    public String getStatus() {
        return status;
    }

    public void confirmar() {
        status = "Confirmado";
    }

    public void cancelar() {
        status = "Cancelado";
    }

    public void exibirDados() {
        System.out.println("------------------------------");
        System.out.println("Agendamento: " + id);
        System.out.println("Usuario: " + usuario.getNome());
        System.out.println("Espaco: " + espaco.getNome());
        System.out.println("Data: " + data);
        System.out.println("Horario: " + horario);
        System.out.println("Status: " + status);
    }
}
