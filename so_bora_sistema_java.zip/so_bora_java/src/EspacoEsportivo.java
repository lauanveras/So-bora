public class EspacoEsportivo {
    private int id;
    private String nome;
    private String endereco;
    private String modalidade;
    private double valorHora;
    private boolean ativo;

    public EspacoEsportivo(int id, String nome, String endereco,
                           String modalidade, double valorHora) {
        this.id = id;
        this.nome = nome;
        this.endereco = endereco;
        this.modalidade = modalidade;
        this.valorHora = valorHora;
        this.ativo = true;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public double getValorHora() {
        return valorHora;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void exibirDados() {
        System.out.println("------------------------------");
        System.out.println("ID: " + id);
        System.out.println("Nome: " + nome);
        System.out.println("Endereco: " + endereco);
        System.out.println("Modalidade: " + modalidade);
        System.out.println("Valor por hora: R$ " + valorHora);
        System.out.println("Ativo: " + ativo);
    }

    public void atualizarDados(String nome, String endereco,
                               String modalidade, double valorHora) {
        this.nome = nome;
        this.endereco = endereco;
        this.modalidade = modalidade;
        this.valorHora = valorHora;
    }

    public void desativar() {
        ativo = false;
    }

    public void ativar() {
        ativo = true;
    }
}
