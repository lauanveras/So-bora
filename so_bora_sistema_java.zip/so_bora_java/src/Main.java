import java.util.Scanner;
import java.time.LocalDate;
import java.time.LocalTime;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        SistemaAgendamento sistema = new SistemaAgendamento();
        int opcao = -1;

        while (opcao != 0) {
            System.out.println("\n========== SO BORA! ==========");
            System.out.println("1 - Cadastrar usuario ou administrador");
            System.out.println("2 - Listar pessoas");
            System.out.println("3 - Buscar pessoa por nome ou matricula");
            System.out.println("4 - Cadastrar espaco esportivo");
            System.out.println("5 - Listar espacos");
            System.out.println("6 - Realizar agendamento");
            System.out.println("7 - Listar agendamentos");
            System.out.println("8 - Cancelar agendamento");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opcao: ");
            opcao = entrada.nextInt();
            entrada.nextLine();

            if (opcao == 1) {
                System.out.println("1 - Usuario");
                System.out.println("2 - Administrador");
                System.out.print("Tipo: ");
                int tipo = entrada.nextInt();
                entrada.nextLine();

                System.out.print("Nome: ");
                String nome = entrada.nextLine();
                System.out.print("Idade: ");
                int idade = entrada.nextInt();
                System.out.print("Altura: ");
                double altura = entrada.nextDouble();
                entrada.nextLine();

                if (tipo == 1) {
                    System.out.print("Email: ");
                    String email = entrada.nextLine();
                    System.out.print("Telefone: ");
                    String telefone = entrada.nextLine();

                    Usuario usuario = new Usuario(nome, idade, altura, email, telefone);
                    sistema.cadastrarPessoa(usuario);
                } else if (tipo == 2) {
                    System.out.print("Nivel de acesso: ");
                    String nivel = entrada.nextLine();

                    Administrador administrador =
                            new Administrador(nome, idade, altura, nivel);
                    sistema.cadastrarPessoa(administrador);
                } else {
                    System.out.println("Tipo invalido.");
                }

            } else if (opcao == 2) {
                sistema.Listar();

            } else if (opcao == 3) {
                System.out.print("Digite o nome ou a matricula: ");
                String busca = entrada.nextLine();
                Pessoa pessoa = sistema.buscarPessoa(busca);

                if (pessoa == null) {
                    System.out.println("Pessoa nao encontrada.");
                } else {
                    System.out.println("Matricula: " + pessoa.getMatricula());
                    pessoa.SeApresentar();
                }

            } else if (opcao == 4) {
                System.out.print("ID do espaco: ");
                int id = entrada.nextInt();
                entrada.nextLine();
                System.out.print("Nome: ");
                String nome = entrada.nextLine();
                System.out.print("Endereco: ");
                String endereco = entrada.nextLine();
                System.out.print("Modalidade: ");
                String modalidade = entrada.nextLine();
                System.out.print("Valor por hora: ");
                double valor = entrada.nextDouble();
                entrada.nextLine();

                EspacoEsportivo espaco = new EspacoEsportivo(
                        id, nome, endereco, modalidade, valor);
                sistema.cadastrarEspaco(espaco);

            } else if (opcao == 5) {
                sistema.listarEspacos();

            } else if (opcao == 6) {
                System.out.print("Matricula do usuario: ");
                String matricula = entrada.nextLine();
                Pessoa pessoa = sistema.buscarPessoa(matricula);

                if (pessoa == null || !(pessoa instanceof Usuario)) {
                    System.out.println("Usuario nao encontrado.");
                } else {
                    Usuario usuario = (Usuario) pessoa;

                    sistema.listarEspacos();
                    System.out.print("ID do espaco: ");
                    int idEspaco = entrada.nextInt();
                    entrada.nextLine();

                    EspacoEsportivo espacoEscolhido = null;
                    for (EspacoEsportivo espaco : sistema.getEspacos()) {
                        if (espaco.getId() == idEspaco) {
                            espacoEscolhido = espaco;
                        }
                    }

                    if (espacoEscolhido == null) {
                        System.out.println("Espaco nao encontrado.");
                    } else {
                        System.out.print("Data (AAAA-MM-DD): ");
                        LocalDate data = LocalDate.parse(entrada.nextLine());
                        System.out.print("Horario (HH:MM): ");
                        LocalTime horario = LocalTime.parse(entrada.nextLine());

                        int idAgendamento = sistema.getAgendamentos().size() + 1;
                        Agendamento agendamento = new Agendamento(idAgendamento,
                                usuario, espacoEscolhido, data, horario, "Confirmado");
                        sistema.realizarAgendamento(agendamento);
                    }
                }

            } else if (opcao == 7) {
                sistema.listarAgendamentos();

            } else if (opcao == 8) {
                System.out.print("ID do agendamento: ");
                int id = entrada.nextInt();
                entrada.nextLine();
                sistema.cancelarAgendamento(id);

            } else if (opcao == 0) {
                System.out.println("Sistema encerrado.");

            } else {
                System.out.println("Opcao invalida.");
            }
        }

        entrada.close();
    }
}
