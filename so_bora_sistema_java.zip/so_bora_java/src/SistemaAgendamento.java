import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.time.LocalTime;

public class SistemaAgendamento {
    private List<Pessoa> pessoas;
    private List<EspacoEsportivo> espacos;
    private List<Agendamento> agendamentos;

    public SistemaAgendamento() {
        pessoas = new ArrayList<Pessoa>();
        espacos = new ArrayList<EspacoEsportivo>();
        agendamentos = new ArrayList<Agendamento>();
    }

    public List<Pessoa> getPessoas() {
        return pessoas;
    }

    public List<EspacoEsportivo> getEspacos() {
        return espacos;
    }

    public List<Agendamento> getAgendamentos() {
        return agendamentos;
    }

    public void cadastrarPessoa(Pessoa pessoa) {
        pessoa.setMatricula(pessoas.size() + 1);
        pessoas.add(pessoa);
        System.out.println("Pessoa cadastrada! Matricula: " + pessoa.getMatricula());
    }

    public void cadastrarEspaco(EspacoEsportivo espaco) {
        espacos.add(espaco);
        System.out.println("Espaco cadastrado com sucesso!");
    }

    public Pessoa buscarPessoa(String nomeOuMatricula) {
        for (Pessoa pessoa : pessoas) {
            if (pessoa.getNome().equalsIgnoreCase(nomeOuMatricula)) {
                return pessoa;
            }

            if (String.valueOf(pessoa.getMatricula()).equals(nomeOuMatricula)) {
                return pessoa;
            }
        }
        return null;
    }

    public void Listar() {
        if (pessoas.size() == 0) {
            System.out.println("Nenhuma pessoa cadastrada.");
        }

        for (Pessoa pessoa : pessoas) {
            System.out.println("------------------------------");
            System.out.println("Matricula: " + pessoa.getMatricula());
            pessoa.SeApresentar();
        }
    }

    public void listarEspacos() {
        if (espacos.size() == 0) {
            System.out.println("Nenhum espaco cadastrado.");
        }

        for (EspacoEsportivo espaco : espacos) {
            espaco.exibirDados();
        }
    }

    public boolean consultarDisponibilidade(LocalDate data, LocalTime horario,
                                            EspacoEsportivo espaco) {
        if (!espaco.isAtivo()) {
            return false;
        }

        for (Agendamento agendamento : agendamentos) {
            if (agendamento.getEspaco().getId() == espaco.getId()
                    && !agendamento.getStatus().equals("Cancelado")
                    && agendamento.getData().equals(data)
                    && agendamento.getHorario().equals(horario)) {
                return false;
            }
        }
        return true;
    }

    public boolean realizarAgendamento(Agendamento agendamento) {
        if (!pessoas.contains(agendamento.getUsuario())) {
            System.out.println("Usuario nao cadastrado.");
            return false;
        }

        if (!espacos.contains(agendamento.getEspaco())) {
            System.out.println("Espaco nao cadastrado.");
            return false;
        }

        if (!consultarDisponibilidade(agendamento.getData(),
                agendamento.getHorario(), agendamento.getEspaco())) {
            System.out.println("Espaco indisponivel nesse horario.");
            return false;
        }

        agendamentos.add(agendamento);
        System.out.println("Agendamento realizado com sucesso!");
        return true;
    }

    public boolean cancelarAgendamento(int id) {
        for (Agendamento agendamento : agendamentos) {
            if (agendamento.getId() == id) {
                agendamento.cancelar();
                System.out.println("Agendamento cancelado.");
                return true;
            }
        }

        System.out.println("Agendamento nao encontrado.");
        return false;
    }

    public void listarAgendamentos() {
        if (agendamentos.size() == 0) {
            System.out.println("Nenhum agendamento cadastrado.");
        }

        for (Agendamento agendamento : agendamentos) {
            agendamento.exibirDados();
        }
    }
}
