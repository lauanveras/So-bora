public class Usuario extends Pessoa {
    private String email;
    private String telefone;

    public Usuario(String nome, int idade, double altura, String email, String telefone) {
        super(nome, idade, altura);
        this.email = email;
        this.telefone = telefone;
    }

    @Override
    public void SeApresentar() {
        System.out.println("Tipo: Usuario");
        super.SeApresentar();
        System.out.println("Email: " + email);
        System.out.println("Telefone: " + telefone);
    }

    public void consultarAgendamentos(SistemaAgendamento sistema) {
        boolean encontrou = false;

        for (Agendamento agendamento : sistema.getAgendamentos()) {
            if (agendamento.getUsuario() == this) {
                agendamento.exibirDados();
                encontrou = true;
            }
        }

        if (!encontrou) {
            System.out.println("Este usuario ainda nao possui agendamentos.");
        }
    }
}
